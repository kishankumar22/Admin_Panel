const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const cloudinary = require('../config/cloudinaryConfig');
const { sql, executeQuery } = require('../config/db');
const router = express.Router();

// Load STORAGE_PATH from environment variable
require('dotenv').config();
const STORAGE_PATH = process.env.STORAGE_PATH || './public/uploads';

// Function to create folder
const createFolderIfNotExists = (folderPath) => {
  if (!fs.existsSync(folderPath)) {
    fs.mkdirSync(folderPath, { recursive: true });
    console.log(`Folder created at: ${folderPath}`);
  } else {
    console.log(`Folder already exists: ${folderPath}`);
  }
};

// Ensure storage directory exists with proper permissions
const initializeStorage = () => {
  createFolderIfNotExists(STORAGE_PATH);
  const facultyFolder = path.join(STORAGE_PATH, 'faculties');
  createFolderIfNotExists(facultyFolder);
  try {
    fs.chmodSync(STORAGE_PATH, 0o755);
    fs.chmodSync(facultyFolder, 0o755);
  } catch (err) {
    console.error(`Error setting permissions for ${folderPath}:`, err.message);
  }
};

// Initialize the storage on server startup
initializeStorage();

// Handle duplicate file names by appending _1, _2, etc.
const getUniqueFileName = (fileName, storagePath) => {
  let newFileName = fileName;
  let counter = 1;
  const ext = path.extname(fileName);
  const baseName = path.basename(fileName, ext);

  while (fs.existsSync(path.join(storagePath, newFileName))) {
    newFileName = `${baseName}_${counter}${ext}`;
    counter++;
  }

  return newFileName;
};

// Multer memory storage configuration
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// 1. GET All Faculties
router.get('/faculty', async (req, res) => {
  try {
    const result = await executeQuery('SELECT * FROM Faculty ORDER BY faculty_name ASC');
    const faculties = result.recordset.map(faculty => {
      if (faculty.documents) {
        try {
          const docs = JSON.parse(faculty.documents);
          faculty.documents = JSON.stringify(docs.filter(doc => {
            const url = doc.url;

            // Always include Cloudinary URLs
            if (url.includes('res.cloudinary.com')) {
              return true;
            }

            // For local files, check if they exist
            const fileName = path.basename(url);
            const filePath = path.join(STORAGE_PATH, fileName);
            const exists = fs.existsSync(filePath);
            if (!exists) {
              console.log(`Local file not found: ${filePath}`);
            }
            return exists;
          }));
        } catch (error) {
          console.error(`Error parsing documents for faculty ${faculty.id}:`, error.message);
          faculty.documents = null;
        }
      }
      return faculty;
    });

    return res.status(200).json(faculties);
  } catch (err) {
    console.error('Error fetching faculties:', err);
    return res.status(500).json({ success: false, message: 'Error fetching faculties', error: err.message });
  }
});


// 2. POST Add Faculty
router.post('/faculty/add', upload.fields([
  { name: 'profilePic', maxCount: 1 },
  { name: 'documents', maxCount: 10 }
]), async (req, res) => {
  try {
    const {
      faculty_name,
      qualification,
      designation,
      created_by,
      monthlySalary,
      yearlyLeave,
      IsVisible,
      documentTitles
    } = req.body;

    if (!faculty_name || !qualification || !designation || !created_by) {
      return res.status(400).json({ success: false, message: 'Missing required fields' });
    }

    let profilePicUrl = null;
    let documents = [];

    // Upload profile picture to Cloudinary
    if (req.files && req.files.profilePic && req.files.profilePic.length > 0) {
      const file = req.files.profilePic[0];
      if (!file.buffer) {
        return res.status(400).json({ success: false, message: 'Invalid profile picture file' });
      }
      const uploadResult = await new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
          { resource_type: 'auto', folder: 'faculties' },
          (error, result) => {
            if (error) return reject(error);
            resolve(result);
          }
        );
        stream.end(file.buffer);
      });
      profilePicUrl = uploadResult.secure_url;
      console.log(`Profile picture uploaded to Cloudinary: ${profilePicUrl}`);
    }

    // Save documents locally with unique names
    const titles = documentTitles ? JSON.parse(documentTitles) : [];
    if (req.files && req.files.documents && req.files.documents.length > 0) {
      const facultyFolder = path.join(STORAGE_PATH, 'faculties');
      createFolderIfNotExists(facultyFolder);
      const documentFiles = req.files.documents;
      for (let i = 0; i < documentFiles.length; i++) {
        const file = documentFiles[i];
        if (!file.buffer) {
          console.error(`Invalid document file at index ${i}: No buffer`);
          continue; // Skip invalid files
        }
        const originalFileName = file.originalname;
        const uniqueFileName = getUniqueFileName(originalFileName, facultyFolder);
        const filePath = path.join(facultyFolder, uniqueFileName);

        try {
          fs.writeFileSync(filePath, file.buffer);
          fs.chmodSync(filePath, 0o444);
          console.log(`Document saved: ${filePath}`);
          const title = titles[i] || originalFileName;
          documents.push({ title, url: `/faculties/${uniqueFileName}` });
        } catch (err) {
          console.error(`Error saving document ${uniqueFileName}:`, err.message);
        }
      }
    }

    const query = `
      INSERT INTO Faculty (
        faculty_name, qualification, designation, profilePicUrl, documents,
        monthlySalary, yearlyLeave, created_by, created_on, IsVisible
      )
      OUTPUT INSERTED.*
      VALUES (
        @facultyName, @qualification, @designation, @profilePicUrl, @documents,
        @monthlySalary, @yearlyLeave, @createdBy, GETDATE(), @isVisible
      )
    `;

    const result = await executeQuery(query, {
      facultyName: { type: sql.NVarChar, value: faculty_name },
      qualification: { type: sql.NVarChar, value: qualification },
      designation: { type: sql.NVarChar, value: designation },
      profilePicUrl: { type: sql.NVarChar, value: profilePicUrl },
      documents: { type: sql.NVarChar, value: documents.length > 0 ? JSON.stringify(documents) : null },
      monthlySalary: { type: sql.Int, value: monthlySalary ? parseInt(monthlySalary) : null },
      yearlyLeave: { type: sql.Int, value: yearlyLeave ? parseInt(yearlyLeave) : null },
      createdBy: { type: sql.NVarChar, value: created_by },
      isVisible: { type: sql.Bit, value: IsVisible !== undefined ? JSON.parse(IsVisible) : true },
    });

    return res.status(201).json({
      success: true,
      message: 'Faculty added successfully',
      faculty: result.recordset[0]
    });
  } catch (err) {
    console.error('Error adding faculty:', err);
    return res.status(500).json({ success: false, message: 'Error adding faculty', error: err.message });
  }
});

// 3. PUT Update Faculty
router.put('/faculty/update/:id', upload.fields([
  { name: 'profilePic', maxCount: 1 },
  { name: 'documents', maxCount: 10 }
]), async (req, res) => {
  try {
    const { id } = req.params;
    const {
      faculty_name,
      qualification,
      designation,
      monthlySalary,
      yearlyLeave,
      modify_by,
      IsVisible,
      documentTitles,
      existingDocuments
    } = req.body;

    const existing = await executeQuery(
      `SELECT * FROM Faculty WHERE id = @id`,
      { id: { type: sql.Int, value: parseInt(id) } }
    );

    if (existing.recordset.length === 0) {
      return res.status(404).json({ success: false, message: 'Faculty not found' });
    }

    let profilePicUrl = existing.recordset[0].profilePicUrl;
    let documents = existingDocuments ? JSON.parse(existingDocuments) : [];

    // Upload profile picture to Cloudinary
    if (req.files && req.files.profilePic && req.files.profilePic.length > 0) {
      const file = req.files.profilePic[0];
      if (!file.buffer) {
        return res.status(400).json({ success: false, message: 'Invalid profile picture file' });
      }
      const uploadResult = await new Promise((resolve, reject) => {
        const stream = cloudinary.uploader.upload_stream(
          { resource_type: 'auto', folder: 'faculties' },
          (error, result) => {
            if (error) return reject(error);
            resolve(result);
          }
        );
        stream.end(file.buffer);
      });
      profilePicUrl = uploadResult.secure_url;
      console.log(`Profile picture updated to Cloudinary: ${profilePicUrl}`);
    }

    // Save new documents locally with unique names
    const titles = documentTitles ? JSON.parse(documentTitles) : [];
    if (req.files && req.files.documents && req.files.documents.length > 0) {
      const facultyFolder = path.join(STORAGE_PATH, 'faculties');
      createFolderIfNotExists(facultyFolder);
      const documentFiles = req.files.documents;
      for (let i = 0; i < documentFiles.length; i++) {
        const file = documentFiles[i];
        if (!file.buffer) {
          console.error(`Invalid document file at index ${i}: No buffer`);
          continue; // Skip invalid files
        }
        const originalFileName = file.originalname;
        const uniqueFileName = getUniqueFileName(originalFileName, facultyFolder);
        const filePath = path.join(facultyFolder, uniqueFileName);

        try {
          fs.writeFileSync(filePath, file.buffer);
          fs.chmodSync(filePath, 0o444);
          console.log(`Document saved: ${filePath}`);
          const title = titles[i] || originalFileName;
          documents.push({ title, url: `/faculties/${uniqueFileName}` });
        } catch (err) {
          console.error(`Error saving document ${uniqueFileName}:`, err.message);
        }
      }
    }

    const query = `
      UPDATE Faculty
      SET 
        faculty_name = @facultyName,
        qualification = @qualification,
        designation = @designation,
        profilePicUrl = @profilePicUrl,
        documents = @documents,
        monthlySalary = @monthlySalary,
        yearlyLeave = @yearlyLeave,
        modify_by = @modifyBy,
        modify_on = GETDATE(),
        IsVisible = @isVisible
      OUTPUT INSERTED.*
      WHERE id = @id
    `;

    const result = await executeQuery(query, {
      id: { type: sql.Int, value: parseInt(id) },
      facultyName: { type: sql.NVarChar, value: faculty_name || existing.recordset[0].faculty_name },
      qualification: { type: sql.NVarChar, value: qualification || existing.recordset[0].qualification },
      designation: { type: sql.NVarChar, value: designation || existing.recordset[0].designation },
      profilePicUrl: { type: sql.NVarChar, value: profilePicUrl },
      documents: { type: sql.NVarChar, value: documents.length > 0 ? JSON.stringify(documents) : null },
      monthlySalary: { type: sql.Int, value: monthlySalary ? parseInt(monthlySalary) : existing.recordset[0].monthlySalary },
      yearlyLeave: { type: sql.Int, value: yearlyLeave ? parseInt(yearlyLeave) : existing.recordset[0].yearlyLeave },
      modifyBy: { type: sql.NVarChar, value: modify_by },
      isVisible: { type: sql.Bit, value: IsVisible !== undefined ? JSON.parse(IsVisible) : existing.recordset[0].IsVisible },
    });

    return res.status(200).json({
      success: true,
      message: 'Faculty updated successfully',
      faculty: result.recordset[0]
    });
  } catch (err) {
    console.error('Error updating faculty:', err);
    return res.status(500).json({ success: false, message: 'Error updating faculty', error: err.message });
  }
});

// 4. DELETE Faculty
router.delete('/faculty/delete/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const result = await executeQuery(
      `SELECT * FROM Faculty WHERE id = @id`,
      { id: { type: sql.Int, value: parseInt(id) } }
    );

    if (result.recordset.length === 0) {
      return res.status(404).json({ success: false, message: 'Faculty not found' });
    }

    // Delete associated local documents
    if (result.recordset[0].documents) {
      try {
        const documents = JSON.parse(result.recordset[0].documents);
        for (const doc of documents) {
          const fileName = path.basename(doc.url);
          const filePath = path.join(STORAGE_PATH, 'faculties', fileName);
          if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            console.log(`Deleted document: ${filePath}`);
          } else {
            console.log(`Document not found for deletion: ${filePath}`);
          }
        }
      } catch (err) {
        console.error(`Error parsing or deleting documents for faculty ${id}:`, err.message);
      }
    }

    await executeQuery(
      `DELETE FROM Faculty WHERE id = @id`,
      { id: { type: sql.Int, value: parseInt(id) } }
    );

    return res.status(200).json({ success: true, message: 'Faculty deleted successfully' });
  } catch (err) {
    console.error('Error deleting faculty:', err);
    return res.status(500).json({ success: false, message: 'Error deleting faculty', error: err.message });
  }
});

// 5. PUT Toggle Faculty Visibility
router.put('/faculty/toggle-visibility/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { modify_by } = req.body;

    const existing = await executeQuery(
      `SELECT * FROM Faculty WHERE id = @id`,
      { id: { type: sql.Int, value: parseInt(id) } }
    );

    if (existing.recordset.length === 0) {
      return res.status(404).json({ success: false, message: 'Faculty not found' });
    }

    const query = `
      UPDATE Faculty
      SET IsVisible = @isVisible,
          modify_by = @modifyBy,
          modify_on = GETDATE()
      OUTPUT INSERTED.*
      WHERE id = @id
    `;

    const result = await executeQuery(query, {
      id: { type: sql.Int, value: parseInt(id) },
      isVisible: { type: sql.Bit, value: !existing.recordset[0].IsVisible },
      modifyBy: { type: sql.NVarChar, value: modify_by },
    });

    return res.status(200).json({
      success: true,
      message: 'Faculty visibility updated successfully',
      faculty: result.recordset[0]
    });
  } catch (err) {
    console.error('Error updating faculty visibility:', err);
    return res.status(500).json({ success: false, message: 'Error updating faculty visibility', error: err.message });
  }
});

// 6. Serve Documents
router.get('/upload/:fileName', (req, res) => {
  const fileName = req.params.fileName;
  const filePath = path.join(STORAGE_PATH, 'faculties', fileName);
  if (fs.existsSync(filePath)) {
    console.log(`Serving file: ${filePath}`);
    return res.sendFile(filePath);
  } else {
    console.log(`File not found: ${filePath}`);
    return res.status(404).json({ success: false, message: 'File not found' });
  }
});

// 7. PUT Update Document Title
router.put('/faculty/:id/update-document-title', async (req, res) => {
  try {
    const { id } = req.params;
    const { docIndex, newTitle } = req.body;

    if (!id || isNaN(id)) {
      return res.status(400).json({ success: false, message: 'Invalid faculty ID' });
    }
    if (docIndex === undefined || isNaN(docIndex) || docIndex < 0) {
      return res.status(400).json({ success: false, message: 'Invalid document index' });
    }
    if (!newTitle || typeof newTitle !== 'string') {
      return res.status(400).json({ success: false, message: 'New title must be a non-empty string' });
    }

    const result = await executeQuery('SELECT * FROM Faculty WHERE id = @id', {
      id: { type: sql.Int, value: parseInt(id) }
    });

    if (!result.recordset || result.recordset.length === 0) {
      return res.status(404).json({ success: false, message: 'Faculty not found' });
    }

    const faculty = result.recordset[0];
    let documents;

    try {
      documents = faculty.documents ? JSON.parse(faculty.documents) : [];
      if (!Array.isArray(documents)) {
        documents = [];
      }
    } catch (error) {
      console.error('Error parsing faculty.documents:', error);
      documents = [];
    }

    if (docIndex >= documents.length) {
      return res.status(400).json({ success: false, message: 'Document index out of bounds' });
    }

    documents[docIndex].title = newTitle;

    const documentsString = JSON.stringify(documents);
    await executeQuery(
      'UPDATE Faculty SET documents = @documents WHERE id = @id',
      {
        id: { type: sql.Int, value: parseInt(id) },
        documents: { type: sql.NVarChar, value: documents.length > 0 ? documentsString : null }
      }
    );

    const updatedResult = await executeQuery('SELECT * FROM Faculty WHERE id = @id', {
      id: { type: sql.Int, value: parseInt(id) }
    });
    const updatedFaculty = updatedResult.recordset[0];

    return res.status(200).json(updatedFaculty);
  } catch (err) {
    console.error('Error updating document title:', err);
    return res.status(500).json({ success: false, message: 'Error updating document title', error: err.message });
  }
});

// Serve static files
router.use('/', express.static(STORAGE_PATH));

module.exports = router;